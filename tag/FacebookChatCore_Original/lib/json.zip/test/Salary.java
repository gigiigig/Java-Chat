package test;

public class Salary {
    int basicPay = -1;

    public Salary(int basicPay) {
        this.basicPay = basicPay;
    }

    public int getBasicPay() {
        return basicPay;
    }
    public void setBasicPay(int basicPay) {
        this.basicPay = basicPay;
    }

}
